--table creation
create table Registrant(
	Id int primary key identity,
	FullName varchar(max) not null,
	Email varchar(max) not null,
	DateOfBirth date not null,
	EmailOptIn bit not null,
	RegistrationDateTime datetime2 not null,
)

create table RegistrantInteger(
	Id int primary  key identity,
	RegistrantId int foreign key references Registrant not null,
	IntegerValue int
)